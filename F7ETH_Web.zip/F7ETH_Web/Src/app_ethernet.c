/**
  ******************************************************************************
  * @file    LwIP/LwIP_HTTP_Server_Raw/Src/app_ethernet.c 
  * @author  MCD Application Team
  * @version V1.3.4
  * @date    06-May-2016
  * @brief   Ethernet specefic module
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright � 2016 STMicroelectronics International N.V. 
  * All rights reserved.</center></h2>
  *
  * Redistribution and use in source and binary forms, with or without 
  * modification, are permitted, provided that the following conditions are met:
  *
  * 1. Redistribution of source code must retain the above copyright notice, 
  *    this list of conditions and the following disclaimer.
  * 2. Redistributions in binary form must reproduce the above copyright notice,
  *    this list of conditions and the following disclaimer in the documentation
  *    and/or other materials provided with the distribution.
  * 3. Neither the name of STMicroelectronics nor the names of other 
  *    contributors to this software may be used to endorse or promote products 
  *    derived from this software without specific written permission.
  * 4. This software, including modifications and/or derivative works of this 
  *    software, must execute solely and exclusively on microcontroller or
  *    microprocessor devices manufactured by or for STMicroelectronics.
  * 5. Redistribution and use of this software other than as permitted under 
  *    this license is void and will automatically terminate your rights under 
  *    this license. 
  *
  * THIS SOFTWARE IS PROVIDED BY STMICROELECTRONICS AND CONTRIBUTORS "AS IS" 
  * AND ANY EXPRESS, IMPLIED OR STATUTORY WARRANTIES, INCLUDING, BUT NOT 
  * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
  * PARTICULAR PURPOSE AND NON-INFRINGEMENT OF THIRD PARTY INTELLECTUAL PROPERTY
  * RIGHTS ARE DISCLAIMED TO THE FULLEST EXTENT PERMITTED BY LAW. IN NO EVENT 
  * SHALL STMICROELECTRONICS OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
  * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
  * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, 
  * OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF 
  * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING 
  * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
  * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
  *
  ******************************************************************************
  */
/* Includes ------------------------------------------------------------------*/
#include "lwip/opt.h"
#include "lwip/dhcp.h"
#include "app_ethernet.h"
#include "ethernetif.h"

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/


/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/
/**
  * @brief  Notify the User about the nework interface config status 
  * @param  netif: the network interface
  * @retval None
  */
void User_notification(struct netif *netif) 
{
  if (netif_is_up(netif))
  {
    /* Turn On LED 2 to indicate ETH and LwIP init success*/
    HAL_GPIO_WritePin(GPIOB,GPIO_PIN_7, GPIO_PIN_SET);
  }
  else
  {     
    /* Turn On LED 3 to indicate ETH and LwIP init error */
    HAL_GPIO_WritePin(GPIOB,GPIO_PIN_14, GPIO_PIN_SET);
    while(1);
  } 
}

///**
//  * @brief  This function notify user about link status changement.
//  * @param  netif: the network interface
//  * @retval None
//  */
//void ethernetif_notify_conn_changed(struct netif *netif)
//{
//  ip_addr_t ipaddr;
//  ip_addr_t netmask;
//  ip_addr_t gw;
//  uint8_t IP_ADDRESS[4];
//  uint8_t NETMASK_ADDRESS[4];
//  uint8_t GATEWAY_ADDRESS[4];
//
//  IP_ADDRESS[0] = 192;
//  IP_ADDRESS[1] = 168;
//  IP_ADDRESS[2] = 15;
//  IP_ADDRESS[3] = 81;
//  NETMASK_ADDRESS[0] = 255;
//  NETMASK_ADDRESS[1] = 255;
//  NETMASK_ADDRESS[2] = 255;
//  NETMASK_ADDRESS[3] = 0;
//  GATEWAY_ADDRESS[0] = 192;
//  GATEWAY_ADDRESS[1] = 168;
//  GATEWAY_ADDRESS[2] = 15;
//  GATEWAY_ADDRESS[3] = 1;
//
//  if(netif_is_link_up(netif))
//  {
//    IP4_ADDR(&ipaddr, IP_ADDRESS[0], IP_ADDRESS[1], IP_ADDRESS[2], IP_ADDRESS[3]);
//    IP4_ADDR(&netmask, NETMASK_ADDRESS[0], NETMASK_ADDRESS[1] , NETMASK_ADDRESS[2], NETMASK_ADDRESS[3]);
//    IP4_ADDR(&gw, GATEWAY_ADDRESS[0], GATEWAY_ADDRESS[1], GATEWAY_ADDRESS[2], GATEWAY_ADDRESS[3]);
//
//    netif_set_addr(netif, &ipaddr , &netmask, &gw);
//
//    /* When the netif is fully configured this function must be called.*/
//    netif_set_up(netif);
//  }
//  else
//  {
//    /*  When the netif link is down this function must be called.*/
//    netif_set_down(netif);
//  }
//}


/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
